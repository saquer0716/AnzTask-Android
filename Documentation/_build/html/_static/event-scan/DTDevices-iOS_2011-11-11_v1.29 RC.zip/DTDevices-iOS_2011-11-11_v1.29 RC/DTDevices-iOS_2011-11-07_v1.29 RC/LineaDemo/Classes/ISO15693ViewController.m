#import "ISO15693ViewController.h"


@implementation ISO15693ViewController

@synthesize cards;

-(BOOL)textFieldShouldEndEditing:(UITextField *)textField;
{
	return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField;
{
	[textField resignFirstResponder];
	return YES;
}

-(void)displayAlert:(NSString *)title message:(NSString *)message
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:message delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
	[alert show];
}


static int stringToHex(NSString *str, uint8_t *data, int length)
{
    NSString *t=[[str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] lowercaseString];
    
    if(length==-1)
        length=([t length]+1)/3;
    
    if([t length]!=(length*3-1))
        return FALSE;
    for(int i=0;i<[t length];i++)
    {
        char c=[t characterAtIndex:i];
        if((c<'0' || c>'9') && (c<'a' || c>'f') && c!=' ')
            return 0;
    }
    
    for(int i=0;i<length;i++)
    {
        char c=[t characterAtIndex:i*3];
        if(c>='a')
            data[i]=c-'a'+10;
        else
            data[i]=c-'0';
        data[i]<<=4;
        
        c=[t characterAtIndex:i*3+1];
        if(c>='a')
            data[i]|=c-'a'+10;
        else
            data[i]|=c-'0';
    }
    return length;
}

static NSString *hexToString(NSString * label, void *data, int length)
{
	const char HEX[]="0123456789ABCDEF";
	char s[2000];
	for(int i=0;i<length;i++)
	{
		s[i*3]=HEX[((uint8_t *)data)[i]>>4];
		s[i*3+1]=HEX[((uint8_t *)data)[i]&0x0f];
		s[i*3+2]=' ';
	}
	s[length*3]=0;
	
    if(label)
        return [NSString stringWithFormat:@"%@(%d): %s",label,length,s];
    else
        return [NSString stringWithCString:s encoding:NSASCIIStringEncoding];
}

-(IBAction)readCard:(id)sender
{
	NS_DURING
    NSError *err;

    if(selectedCard!=-1)
        if(![linea iso15693SelectCard:[cards objectAtIndex:selectedCard] error:&err])
        {
            [self displayAlert:@"Select card failed" message:[err localizedDescription]];
            return;
        }
    
    NSData *data=[linea iso15693ReadBlocks:[readBlockField.text intValue] nBlocks:[readBlockNumField.text intValue] error:&err];
    if(!data)
    {
        [self displayAlert:@"Read blocks failed" message:[err localizedDescription]];
        return;
    }
    
    [readDataView setText:hexToString(nil,(uint8_t *)[data bytes],[data length])];
    [self displayAlert:NSLocalizedString(@"Operation successful!",nil) message:@"\n"];
        
	NS_HANDLER
	[self displayAlert:NSLocalizedString(@"Operation failed!",nil) message:[NSString stringWithFormat:@"%@ - %@",[localException name],[localException reason]]];
	NS_ENDHANDLER
    [linea mfClose];
}

-(IBAction)writeCard:(id)sender
{
	NS_DURING
    uint8_t data[512];
    NSError *err;
    
    int length=stringToHex(writeDataField.text,data,-1);
    if(!length || length&3)
    {
        [self displayAlert:NSLocalizedString(@"Operation failed!",nil) message:NSLocalizedString(@"Data is invalid, have to be multiple by 4",nil)];
        return;
    }
    
    if(selectedCard!=-1)
        if(![linea iso15693SelectCard:[cards objectAtIndex:selectedCard] error:&err])
        {
            [self displayAlert:@"Select card failed" message:[err localizedDescription]];
            return;
        }
    
    int written=[linea iso15693WriteBlocks:[writeBlockField.text intValue] blockSize:4 nBlocks:length/4 data:[NSData dataWithBytes:data length:length] error:&err];
    if(!written)
    {
        [self displayAlert:@"Write blocks failed" message:[err localizedDescription]];
        return;
    }
    [self displayAlert:NSLocalizedString(@"Operation successful!",nil) message:@"\n"];
	NS_HANDLER
	[self displayAlert:NSLocalizedString(@"Operation failed!",nil) message:[NSString stringWithFormat:@"%@ - %@",[localException name],[localException reason]]];
	NS_ENDHANDLER
}

-(IBAction)scanCards:(id)sender
{
	NS_DURING
    NSError *err;
    
    selectedCard=-1;
    self.cards=nil;
    self.cards=[linea iso15693ScanCards:&err];
    if(!self.cards)
    {
        [self displayAlert:@"Scan cards failed" message:[err localizedDescription]];
        return;
    }
	NS_HANDLER
	[self displayAlert:NSLocalizedString(@"Operation failed!",nil) message:[NSString stringWithFormat:@"%@ - %@",[localException name],[localException reason]]];
	NS_ENDHANDLER
	[cardsTableView reloadData];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSString *)tableView:(UITableView *)aTableView titleForHeaderInSection:(NSInteger)section {
	return @"";
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if(cards)
        return [cards count];
    
    return 0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    selectedCard=indexPath.row;
	[tableView reloadData];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	CGRect CellFrame = CGRectMake(0, 0, 300, 60);
	UITableViewCell *cell = [[UITableViewCell alloc] initWithFrame:CellFrame];
    
    if(selectedCard==indexPath.row)
        cell.accessoryType=UITableViewCellAccessoryCheckmark;
    else
        cell.accessoryType=UITableViewCellAccessoryNone;
    [[cell textLabel] setText:hexToString(nil,(uint8_t *)[[cards objectAtIndex:indexPath.row] bytes],[[cards objectAtIndex:indexPath.row] length])];
    return cell;
}

-(void)viewWillAppear:(BOOL)animated
{
    NS_DURING
    [linea iso15693SetEnabled:TRUE error:nil];
	NS_HANDLER
	[self displayAlert:NSLocalizedString(@"Operation failed!",nil) message:[NSString stringWithFormat:@"%@ - %@",[localException name],[localException reason]]];
	NS_ENDHANDLER
}

-(void)viewWillDisappear:(BOOL)animated
{
    NS_DURING
    [linea iso15693SetEnabled:FALSE error:nil];
	NS_HANDLER
	NS_ENDHANDLER
}

-(void)viewDidLoad
{
    self.cards=nil;
    selectedCard=-1;
	
	//we don't care about Linea notifications here, so won't add the delegate
	linea=[Linea sharedDevice];
    [super viewDidLoad];
}


@end

