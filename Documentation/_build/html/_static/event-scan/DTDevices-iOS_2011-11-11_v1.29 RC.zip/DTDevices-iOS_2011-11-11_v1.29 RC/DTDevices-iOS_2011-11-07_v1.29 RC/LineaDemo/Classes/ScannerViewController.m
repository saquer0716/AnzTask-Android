#import "ScannerViewController.h"
#import "NSDataCrypto.h"


//#define LOG_FILE

@implementation ScannerViewController

@synthesize lastBarcode;
@synthesize lastBarcodeType;
@synthesize lastCardName;
@synthesize lastCardNumber;
@synthesize lastExpDate;
@synthesize lastCardTrack1;
@synthesize lastCardTrack2;
@synthesize lastCardTrack3;


-(NSString *)getLogFile
{
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	return [[paths objectAtIndex:0] stringByAppendingPathComponent:@"log.txt"];
}

-(void)debug:(NSString *)text
{
	NSDateFormatter *dateFormat=[[NSDateFormatter alloc] init];
	[dateFormat setDateFormat:@"HH:mm:ss:SSS"];
	NSString *timeString = [dateFormat stringFromDate:[NSDate date]];
	
	NS_DURING
	if([debug length]>4000)
		[debug setString:@""];
	[debug appendFormat:@"%@-%@\n",timeString,text];
	NS_HANDLER
	NS_ENDHANDLER
	[debugText setText:debug];
#ifdef LOG_FILE
	[debug writeToFile:[self getLogFile]  atomically:YES];
#endif
}

-(void)displayAlert:(NSString *)title message:(NSString *)message
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:message delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
	[alert show];
}

-(void)updateBattery
{
    NS_DURING
	int percent=[linea getBatteryCapacity];
    int voltage=[linea getBatteryVoltage];
    [voltageLabel setText:[NSString stringWithFormat:@"%d.%dv",voltage/10,voltage%10]];
	[battery setHidden:FALSE];
	[voltageLabel setHidden:FALSE];
	if(percent<10)
		[battery setImage:[UIImage imageNamed:@"0.png"]];
	else if(percent<40)
		[battery setImage:[UIImage imageNamed:@"25.png"]];
	else if(percent<60)
		[battery setImage:[UIImage imageNamed:@"50.png"]];
	else if(percent<80)
		[battery setImage:[UIImage imageNamed:@"75.png"]];
	else
		[battery setImage:[UIImage imageNamed:@"100.png"]];
    NS_HANDLER
	[battery setHidden:TRUE];
	[voltageLabel setHidden:TRUE];
    NS_ENDHANDLER
}

-(IBAction)onPrint:(id)sender
{
	[debug setString:@""];
	NSString *selectedPrinterAddress=[[NSUserDefaults standardUserDefaults] objectForKey:@"selectedPrinterAddress"];

	
    if(!selectedPrinterAddress || ![selectedPrinterAddress length])
	{
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Bluetooth printing",nil)
														message:NSLocalizedString(@"Please discover and select bluetooth printer from the settings.",nil) delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
		[alert show];
		return;
	}
	
	NS_DURING
    [progressViewController viewWillAppear:FALSE];
	[self.view addSubview:progressViewController.view];
	[[NSRunLoop currentRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.01]];
	
	[linea btmSetEnabled:TRUE];
    
    if([linea btConnect:selectedPrinterAddress pin:@"0000"])
	{
        Printer *prn=[Printer sharedDevice];
        prn.delegate=self;
        if([prn connectWithStreams:linea.btInputStream outputStream:linea.btOutputStream])
        {
            [prn printLogo:0];
            
            //[prn printImage:[UIImage imageNamed:@"taz.png"]];
            //[prn feedPaper:30];
            
            if(self.lastBarcode)
            {
                [prn printText:[NSString stringWithFormat:@"{+B}Barcode:{-B} %@\n",self.lastBarcode]];
                [prn printText:[NSString stringWithFormat:@"{+B}Type:{-B} %@\n",self.lastBarcodeType]];
                [prn feedPaper:30];
            }
            if(self.lastCardName)
                [prn printText:[NSString stringWithFormat:@"{+B}Name:{-B} %@\n",self.lastCardName]];
            if(self.lastCardNumber)
                [prn printText:[NSString stringWithFormat:@"{+B}Number:{-B} %@\n",self.lastCardNumber]];
            if(self.lastExpDate)
                [prn printText:[NSString stringWithFormat:@"{+B}Expires:{-B} %@\n",self.lastExpDate]];
            
            [prn feedPaper:30];
            if(self.lastCardTrack1)
                [prn printText:[NSString stringWithFormat:@"{+B}Track1:{-B} %@\n",self.lastCardTrack1]];
            if(self.lastCardTrack2)
                [prn printText:[NSString stringWithFormat:@"{+B}Track2:{-B} %@\n",self.lastCardTrack2]];
            if(self.lastCardTrack3)
                [prn printText:[NSString stringWithFormat:@"{+B}Track3:{-B} %@\n",self.lastCardTrack3]];
            [prn feedPaper:0];
            [prn flushCache];
            [prn waitPrintJob:50];
        }
	}
 	NS_HANDLER
	[self debug:[NSString stringWithFormat:@"%@ - %@",[localException name],[localException reason]]];
	NS_ENDHANDLER
	[linea btmSetEnabled:FALSE];
	[progressViewController.view removeFromSuperview];
}

-(void)cleanPrintInfo
{
    self.lastBarcode=nil;
	self.lastCardName=nil;
	self.lastCardNumber=nil;
	self.lastExpDate=nil;
	self.lastCardTrack1=nil;
	self.lastCardTrack2=nil;
	self.lastCardTrack3=nil;
    
	[printButton setHidden:TRUE];
}

-(IBAction)scanDown:(id)sender;
{
	NS_DURING
	[statusImage setImage:[UIImage imageNamed:@"scanning.png"]];
	[displayText setText:@""];
	[self cleanPrintInfo];
	//refresh the screen
	[[NSRunLoop currentRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.01]];
	[linea startScan];
	NS_HANDLER
	[self debug:[NSString stringWithFormat:@"%@ - %@",[localException name],[localException reason]]];
	NS_ENDHANDLER
}

-(IBAction)scanUp:(id)sender;
{
	NS_DURING
	[statusImage setImage:[UIImage imageNamed:@"connected.png"]];
	[linea stopScan];
	NS_HANDLER
	[self debug:[NSString stringWithFormat:@"%@ - %@",[localException name],[localException reason]]];
	NS_ENDHANDLER
}

-(void)connectionState:(int)state {
	switch (state) {
		case CONN_DISCONNECTED:
		case CONN_CONNECTING:
			[statusImage setImage:[UIImage imageNamed:@"disconnected.png"]];
			[displayText setText:@"Scanner not connected"];
			[battery setHidden:TRUE];
			[voltageLabel setHidden:TRUE];
			[scanButton setHidden:TRUE];
			[printButton setHidden:TRUE];
			break;
		case CONN_CONNECTED:
			[statusImage setImage:[UIImage imageNamed:@"connected.png"]];
			[status setString:[NSString stringWithFormat:@"SDK version: %d.%d\n%@ %@ connected\nHardware revision: %@\nFirmware revision: %@\nSerial number: %@",linea.sdkVersion/100,linea.sdkVersion%100,linea.deviceName,linea.deviceModel,linea.hardwareRevision,linea.firmwareRevision,linea.serialNumber]];
			[displayText setText:status];
			[scanButton setHidden:FALSE];
            
            [self updateBattery];
			break;
	}
}

-(void)buttonPressed:(int)which {
	[debug setString:@""];
	[self cleanPrintInfo];
	
	[displayText setText:@""];
	[statusImage setImage:[UIImage imageNamed:@"scanning.png"]];
}

-(void)buttonReleased:(int)which {
	[statusImage setImage:[UIImage imageNamed:@"connected.png"]];
}

-(void)barcodeData:(NSString *)barcode type:(int)type {
	[self cleanPrintInfo];
	
	self.lastBarcode=barcode;
	self.lastBarcodeType=[linea barcodeType2Text:type];
	
	[status setString:@""];
	[status appendFormat:@"Type: %d\n",type];
	[status appendFormat:@"Type text: %@\n",[linea barcodeType2Text:type]];
	[status appendFormat:@"Barcode: %@",barcode];
	[displayText setText:status];
	//if(!settings_values[SET_MULTI_SCAN_MODE])
	//	[statusImage setImage:[UIImage imageNamed:@"normal.png"]];
	NS_DURING
	[self updateBattery];
	NS_HANDLER
	[self debug:[NSString stringWithFormat:@"***%@ - %@",[localException name],[localException reason]]];
	NS_ENDHANDLER
	if([linea.deviceModel rangeOfString:@"BL"].location==NSNotFound)
	{
		[printButton setHidden:TRUE];
	}else {
		[printButton setHidden:FALSE];
	}
}

-(void)magneticCardData:(NSString *)track1 track2:(NSString *)track2 track3:(NSString *)track3 {
	[self cleanPrintInfo];
	
	self.lastCardTrack1=track1;
	self.lastCardTrack2=track2;
	self.lastCardTrack3=track3;
	
	[status setString:@""];
	
	NSDictionary *card=[linea msProcessFinancialCard:track1 track2:track2];
	if(card)
	{
		self.lastCardName=[card valueForKey:@"cardholderName"];
		self.lastCardNumber=[card valueForKey:@"accountNumber"];
		self.lastExpDate=[NSString stringWithFormat:@"%@/%@\n",[card valueForKey:@"expirationMonth"],[card valueForKey:@"expirationYear"]];
		
		
		if(self.lastCardName)
			[status appendFormat:@"Name: %@\n",self.lastCardName];
		if(self.lastCardNumber)
			[status appendFormat:@"Number: %@\n",self.lastCardNumber];
		if(self.lastExpDate)
			[status appendFormat:@"Expiration: %@\n",self.lastExpDate];
		[status appendString:@"\n"];
	}
	
	if(track1!=NULL)
		[status appendFormat:@"Track1: %@\n",track1];
	if(track2!=NULL)
		[status appendFormat:@"Track2: %@\n",track2];
	if(track3!=NULL)
		[status appendFormat:@"Track3: %@\n",track3];
	[displayText setText:status];
	
	int sound[]={2730,150,0,30,2730,150};
	[linea playSound:100 beepData:sound length:sizeof(sound)];
	[self updateBattery];
	if([linea.deviceModel rangeOfString:@"BL"].location==NSNotFound)
	{
		[printButton setHidden:TRUE];
	}else
    {
		[printButton setHidden:FALSE];
	}
}

-(NSString *)toHexString:(void *)data length:(int)length
{
	const char HEX[]="0123456789ABCDEF";
	char s[2000];
	
	int len=0;
	for(int i=0;i<length;i++)
	{
		s[len++]=HEX[((uint8_t *)data)[i]>>4];
		s[len++]=HEX[((uint8_t *)data)[i]&0x0f];
		s[len++]=' ';
	}
	s[len]=0;
	return [NSString stringWithCString:s encoding:NSASCIIStringEncoding];
}

-(void)magneticCardRawData:(NSData *)tracks {
    //NSLog(@"raw data: %@",[self toHexString:(void *)[tracks bytes] length:[tracks length]]);
	[status setString:[self toHexString:(void *)[tracks bytes] length:[tracks length]]];
	[displayText setText:status];
	
	int sound[]={2700,150,5400,150};
	[linea playSound:100 beepData:sound length:sizeof(sound)];
	[self updateBattery];
}

-(uint16_t)crc16:(uint8_t *)data  length:(int)length crc16:(uint16_t)crc16
{
	if(length==0) return 0;
	int i=0;
	while(length--)
	{
		crc16=(uint8_t)(crc16>>8)|(crc16<<8);
		crc16^=*data++;
		crc16^=(uint8_t)(crc16&0xff)>>4;
		crc16^=(crc16<<8)<<4;
		crc16^=((crc16&0xff)<<4)<<1;
		i++;
	}
	return crc16;
}

-(void)magneticJISCardData:(NSString *)data {
    [displayText setText:[NSString stringWithFormat:@"JIS card data:\n%@",data]];

	int sound[]={2730,150,0,30,2730,150};
	[linea playSound:100 beepData:sound length:sizeof(sound)];
	[self updateBattery];
}

-(void)magneticCardEncryptedData:(int)encryption data:(NSData *)data {
    [self magneticCardEncryptedData:encryption tracks:0 data:data];
}

//the new notification, sent by 1.29+ sdk
-(void)magneticCardEncryptedData:(int)encryption tracks:(int)tracks data:(NSData *)data {

    NSLog(@"Encrypted card data, tracks: %d, encryption: %d",tracks,encryption);
    if(tracks!=0)
    {
        //you can check here which tracks are read and discard the data if the requred ones are missing
        // for example:
        //if(!(tracks&2)) return; //bail out if track 2 is not read
    }
	
	//try to decrypt the data
	//uint8_t cryptoData[]={0x88,0xD0,0xE0,0x77,0x38,0x22,0xDE,0x17,0x13,0x17,0x96,0x77,0x72,0x04,0x3C,0xFB,0xB0,0x9F,0x6A,0x84,0x63,0x82,0x2C,0xEF,0xE6,0x80,0xEA,0x97,0xBF,0x6F,0x5E,0xF4,0x86,0x30,0x4B,0x45,0xF8,0x70,0xFC,0xC5,0x27,0xEC,0x65,0x93,0x00,0x6B,0x95,0x3B,0x67,0x07,0xDC,0xE0,0x04,0x5F,0xA6,0xFD,0xFC,0x3B,0x07,0xB8,0x75,0x63,0x6C,0x18,0x31,0x28,0x50,0xF0,0xDB,0xF7,0x23,0x3E,0xF7,0x10,0xF5,0xFA,0xA9,0x8E,0x94,0x28,0x6E,0xC6,0x01,0x30,0xD5,0xAB,0xE5,0x1A,0xC9,0x60,0x90,0xBE,0xBB,0x70,0x80,0x1D,0x7E,0xFD,0xFE,0xD4,0x9E,0x2B,0xD7,0x4B,0xF7,0x1E,0x74,0xD2,0xBA,0x1A,0x30,0x64,0x84,0xD5,0x27,0xC8,0xF4,0x74,0x66,0x74,0x0C,0x6B,0x25,0xBD,0x96,0x9E,0x5C,0x12};
	//data=[NSData dataWithBytes:cryptoData length:sizeof(cryptoData)];
    
	//last used decryption key is stored in preferences
	NSString *decryptionKey=[[NSUserDefaults standardUserDefaults] objectForKey:@"DecryptionKey"];
	if(decryptionKey==nil || decryptionKey.length!=32)
		decryptionKey=@"11111111111111111111111111111111"; //sample default
	
    NSData *decrypted=[data AESDecryptWithKey:[decryptionKey dataUsingEncoding:NSASCIIStringEncoding]];
	//basic check if the decrypted data is valid
	if(decrypted)
	{
		uint8_t *bytes=(uint8_t *)[decrypted bytes];
		for(int i=0;i<([decrypted length]-2);i++)
		{
			if(i>(4+16) && !bytes[i])
			{
				uint16_t crc16=[self crc16:bytes length:(i+1) crc16:0];
				uint16_t crc16Data=(bytes[i+1]<<8)|bytes[i+2];
				
				if(crc16==crc16Data)
				{
					int snLen=0;
					for(snLen=0;snLen<16;snLen++)
						if(!bytes[4+snLen])
							break;
					NSString *sn=[[NSString alloc] initWithBytes:&bytes[4] length:snLen encoding:NSASCIIStringEncoding];
					//do something with that serial number
					NSLog(@"Serial number in encrypted packet: %@",sn);
					
					//crc matches, extract the tracks then
                    int dataLen=i;
                    //check for JIS card
                    if(bytes[4+16]==0xF5)
                    {
                        NSString *data=[[NSString alloc] initWithBytes:&bytes[4+16+1] length:(dataLen-4-16-2) encoding:NSASCIIStringEncoding];
                        //pass to the non-encrypted function to display JIS card
                        [self magneticJISCardData:data];
                    }else
                    {
                        int t1=-1,t2=-1,t3=-1,tend;
                        NSString *track1=nil,*track2=nil,*track3=nil;
                        //find the tracks offset
                        for(int j=(4+16);j<dataLen;j++)
                        {
                            if(bytes[j]==0xF1)
                                t1=j;
                            if(bytes[j]==0xF2)
                                t2=j;
                            if(bytes[j]==0xF3)
                                t3=j;
                        }
                        if(t1!=-1)
                        {
                            if(t2!=-1)
                                tend=t2;
                            else
                                if(t3!=-1)
                                    tend=t3;
                                else
                                    tend=dataLen;
                            track1=[[NSString alloc] initWithBytes:&bytes[t1+1] length:(tend-t1-1) encoding:NSASCIIStringEncoding];
                        }
                        if(t2!=-1)
                        {
                            if(t3!=-1)
                                tend=t3;
                            else
                                tend=dataLen;
                            track2=[[NSString alloc] initWithBytes:&bytes[t2+1] length:(tend-t2-1) encoding:NSASCIIStringEncoding];
                        }
                        if(t3!=-1)
                        {
                            tend=dataLen;
                            track3=[[NSString alloc] initWithBytes:&bytes[t3+1] length:(tend-t3-1) encoding:NSASCIIStringEncoding];
                        }
                        
                        //pass to the non-encrypted function to display tracks
                        [self magneticCardData:track1 track2:track2 track3:track3];
                    }
                    return;
				}
			}
		}
	}
	[status setString:NSLocalizedString(@"Card data cannot be decrypted, possibly key is invalid",nil)];
	[displayText setText:status];
}

- (void)viewWillAppear:(BOOL)animated
{
	//update display according to current linea state
	[self connectionState:linea.connstate];
}

- (void)viewDidLoad
{
	status=[[NSMutableString alloc] init];
	debug=[[NSMutableString alloc] init];
#ifdef LOG_FILE
	NSFileManager *fileManger = [NSFileManager defaultManager];
	if ([fileManger fileExistsAtPath:[self getLogFile]])
	{
		[debug appendString:[[NSString alloc] initWithContentsOfFile:[self getLogFile]]];
		[debugText setText:debug];
	}
#endif
	debugText.font=[debugText.font fontWithSize:8];
	linea=[Linea sharedDevice];
	[linea addDelegate:self];
    
    [super viewDidLoad];
}


@end
