#import "SettingsViewController.h"
#import "NSDataCrypto.h"

@implementation SettingsViewController

@synthesize selectedPrinterName;
@synthesize selectedPrinterAddress;

NSString *settings[]={
	@"Beep upon scan",
	@"Alternative beep",
	@"Enable scan button",
	@"Multi-scan mode",
	@"Enable 6 sec scan timeout",
	@"Magnetic card raw mode",
	@"Sync button enabled", 
	@"Automated charge enabled",
	@"Barcode engine always on"
};

enum SETTINGS{
	SET_BEEP=0,
	SET_ALTERNATIVE_BEEP,
	SET_ENABLE_SCAN_BUTTON,
	SET_MULTI_SCAN_MODE,
	SET_SCAN_TIMEOUT,
	SET_MSR_RAW,
	SET_SYNC_BUTTON,
	SET_AUTOCHARGING,
	SET_ENGINE_ON
};
	
BOOL settings_values[]={TRUE,FALSE,TRUE,FALSE,FALSE,FALSE,TRUE,FALSE,FALSE};

#define TARGET_LINEA 0
#define TARGET_EMSR 1
int fwUpdateTarget=TARGET_LINEA;

int beep1[]={2730,250};
int beep2[]={2730,150,65000,20,2730,150};

-(void)displayAlert:(NSString *)title message:(NSString *)message
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:message delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
	[alert show];
}

-(NSString *)getLineaFirmwareFileName
{
	NSError *err;
	NSString *name=[[linea.deviceName stringByReplacingOccurrencesOfString:@" " withString:@""] lowercaseString];

	NSArray *files=[[NSFileManager defaultManager] contentsOfDirectoryAtPath:[[NSBundle mainBundle] resourcePath] error:&err];
	int lastVer=0;
	NSString *lastPath;
	for(int i=0;i<[files count];i++)
	{
		NSString *file=[[files objectAtIndex:i] lastPathComponent];
        //if([[file lowercaseString] isEqualToString:@"lineapro4c_xbcmbl_243.bin"])
        //    NSLog(@"checking: %@",file);
		if([[file lowercaseString] rangeOfString:name].location!=NSNotFound)
		{
			NSString *path=[[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:file];
			NS_DURING
            NSDictionary *info=[linea getFirmwareFileInformation:[NSData dataWithContentsOfFile:path]];
            NSLog(@"file: %@, name=%@, model=%@",file,[info objectForKey:@"deviceName"],[info objectForKey:@"deviceModel"]);
			if(info && [[info objectForKey:@"deviceName"] isEqualToString:linea.deviceName] && [[info objectForKey:@"deviceModel"] isEqualToString:linea.deviceModel] && [[info objectForKey:@"firmwareRevisionNumber"] intValue]>lastVer)
			{
				lastPath=path;
				lastVer=[[info objectForKey:@"firmwareRevisionNumber"] intValue];
			}
			NS_HANDLER
			NS_ENDHANDLER
		}
	}
	if(lastVer>0)
		return lastPath;
	return nil;
}

-(NSString *)getEMSRFirmwareFileName
{
	NSError *err;
	NSArray *files=[[NSFileManager defaultManager] contentsOfDirectoryAtPath:[[NSBundle mainBundle] resourcePath] error:&err];
	NSString *name=[[[linea emsrGetDeviceModel] stringByReplacingOccurrencesOfString:@" " withString:@""] lowercaseString];
	int lastVer=0;
	NSString *lastPath;
	for(int i=0;i<[files count];i++)
	{
		NSString *file=[[[files objectAtIndex:i] lastPathComponent] lowercaseString];
		if([file rangeOfString:name].location!=NSNotFound)
		{
			NSString *path=[[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:[files objectAtIndex:i]];
			NS_DURING
            NSDictionary *info=[linea emsrGetFirmwareInformation:[NSData dataWithContentsOfFile:path]];
			if(info /*&& [[info objectForKey:@"deviceName"] isEqualToString:[linea emsrGetDeviceModel]] && [[info objectForKey:@"firmwareRevisionNumber"] intValue]>lastVer*/)
			{
				lastPath=path;
				lastVer=[[info objectForKey:@"firmwareRevisionNumber"] intValue];
			}
			NS_HANDLER
			NS_ENDHANDLER
		}
	}
	if(lastVer>0)
		return lastPath;
	return nil;
}

-(void)connectionState:(int)state {
	switch (state) {
		case CONN_DISCONNECTED:
		case CONN_CONNECTING:
			break;
		case CONN_CONNECTED:
			NS_DURING
			//set defaults
			settings_values[SET_BEEP]=TRUE;
			settings_values[SET_ALTERNATIVE_BEEP]=FALSE;
			
			//read settings
			settings_values[SET_ENABLE_SCAN_BUTTON]=([linea getScanButtonMode]==BUTTON_ENABLED);
			settings_values[SET_MULTI_SCAN_MODE]=([linea getScanMode]==MODE_MULTI_SCAN);
			settings_values[SET_SCAN_TIMEOUT]=([linea getScanTimeout]==6);
			settings_values[SET_MSR_RAW]=([linea getMSCardDataMode]==MS_RAW_CARD_DATA);
			settings_values[SET_SYNC_BUTTON]=([linea getSyncButtonMode]==BUTTON_ENABLED);
			settings_values[SET_AUTOCHARGING]=[[NSUserDefaults standardUserDefaults] boolForKey:@"AutoCharging"];
			settings_values[SET_ENGINE_ON]=[[NSUserDefaults standardUserDefaults] boolForKey:@"BarcodeEngineOn"];

			
			NS_HANDLER
			[scannerViewController debug:[NSString stringWithFormat:@"***%@ - %@",[localException name],[localException reason]]];
			NS_ENDHANDLER
			[settingsTable reloadData];
			break;
	}
}

-(void)firmwareUpdateEnd:(NSException *)exception
{
    [progressViewController.view removeFromSuperview];
    if(exception)
        [self displayAlert:NSLocalizedString(@"Firmware Update",nil) message:[NSString stringWithFormat:NSLocalizedString(@"Firmware updated failed with error:\n%@\nReason:\n%@",nil),[exception name],[exception reason]]];
}

-(void)firmwareUpdateDisplayProgress
{
    switch (progressPhase)
    {
        case UPDATE_INIT:
            [progressViewController updateProgress:NSLocalizedString(@"Initializing update...",nil) progress:progressPercent];
            break;
        case UPDATE_ERASE:
            [progressViewController updateProgress:NSLocalizedString(@"Erasing flash...",nil) progress:progressPercent];
            break;
        case UPDATE_WRITE:
            [progressViewController updateProgress:NSLocalizedString(@"Writing firmware...",nil) progress:progressPercent];
            break;
        case UPDATE_FINISH:
            [progressViewController updateProgress:NSLocalizedString(@"Complete!",nil) progress:progressPercent];
            break;
    }
}
    
-(void)firmwareUpdateProgress:(int)phase percent:(int)percent
{
    progressPhase=phase;
    progressPercent=percent;
    [self performSelectorOnMainThread:@selector(firmwareUpdateDisplayProgress) withObject:nil waitUntilDone:FALSE];
}

-(void)firmwareUpdateThread:object
{
	@autoreleasepool {
    
        NS_DURING
        [linea updateFirmware:[self getLineaFirmwareFileName]];
        NS_HANDLER
        [self performSelectorOnMainThread:@selector(firmwareUpdateEnd:) withObject:localException waitUntilDone:FALSE];
        NS_ENDHANDLER
        
        [self performSelectorOnMainThread:@selector(firmwareUpdateEnd:) withObject:nil waitUntilDone:FALSE];
    
    }
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if(buttonIndex == 1)
	{
        if(fwUpdateTarget==TARGET_LINEA)
        {
            NS_DURING
            //In case authentication key is present in the Linea, we need to authenticate with it first, before firmware update is allowed
            //For the sample here I'm using the field "Decryption key" in the crypto settings as data and generally ignoring the result of the
            //authentication operation, firmware update will just fail if authentication have failed
            NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
            //last used decryption key is stored in preferences
            NSString *authenticationKey=[prefs objectForKey:@"AuthenticationKey"];
            if(authenticationKey==nil || authenticationKey.length!=32)
                authenticationKey=@"11111111111111111111111111111111"; //sample default
            
            [linea cryptoAuthenticateiPod:[authenticationKey dataUsingEncoding:NSASCIIStringEncoding]];
            NS_HANDLER
            NS_ENDHANDLER
            
            //Make firmware update more interactive - call it from a thread
            [progressViewController viewWillAppear:FALSE];
            [self.view addSubview:progressViewController.view];
            [NSThread detachNewThreadSelector:@selector(firmwareUpdateThread:) toTarget:self withObject:nil];
            /*
             NS_DURING
             [linea updateFirmware:[self getFirmwareFileName]];
             NS_HANDLER
             [scannerViewController debug:[NSString stringWithFormat:@"%@ - %@",[localException name],[localException reason]]];
             NS_ENDHANDLER
             */
        }
        if(fwUpdateTarget==TARGET_EMSR)
        {
            NS_DURING
            [linea emsrUpdateFirmware:[NSData dataWithContentsOfFile:[self getEMSRFirmwareFileName]]];
            NS_HANDLER
            [scannerViewController debug:[NSString stringWithFormat:@"%@ - %@",[localException name],[localException reason]]];
            NS_ENDHANDLER
        }
	}
}

-(void)checkForLineaFirmwareUpdate;
{
	NSString *file=[self getLineaFirmwareFileName];
	if(file==nil)
	{
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Firmware Update",nil)
														message:NSLocalizedString(@"No firmware for this device model present",nil) delegate:nil cancelButtonTitle:NSLocalizedString(@"Ok",nil) otherButtonTitles:nil, nil];
		[alert show];
	}else {
        NSDictionary *info=[linea getFirmwareFileInformation:[NSData dataWithContentsOfFile:file]];
		
		if([[info objectForKey:@"deviceName"] isEqualToString:linea.deviceName] && [[info objectForKey:@"deviceModel"] isEqualToString:linea.deviceModel])
		{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Firmware Update",nil)
                                                            message:[NSString stringWithFormat:NSLocalizedString(@"Linea ver: %@\nAvailable: %@\n\nDo you want to update firmware?\n\nDO NOT DISCONNECT LINEA DURING FIRMWARE UPDATE!",nil),[linea firmwareRevision],[info objectForKey:@"firmwareRevision"]]
                                                           delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel",nil) otherButtonTitles:NSLocalizedString(@"Update",nil), nil];
            [alert show];
		}else {
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Firmware Update",nil)
															message:NSLocalizedString(@"No firmware for this device model present",nil) delegate:nil cancelButtonTitle:NSLocalizedString(@"Ok",nil) otherButtonTitles:nil, nil];
			[alert show];
		}
	}
}

-(void)checkForEMSRFirmwareUpdate;
{
	NSString *file=[self getEMSRFirmwareFileName];
	if(file==nil)
	{
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Firmware Update",nil)
														message:NSLocalizedString(@"No firmware for this device model present",nil) delegate:nil cancelButtonTitle:NSLocalizedString(@"Ok",nil) otherButtonTitles:nil, nil];
		[alert show];
	}else {
        NSDictionary *info=[linea emsrGetFirmwareInformation:[NSData dataWithContentsOfFile:file]];
		
		if([[info objectForKey:@"deviceModel"] isEqualToString:[linea emsrGetDeviceModel]])
		{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Firmware Update",nil)
                                                            message:[NSString stringWithFormat:NSLocalizedString(@"Head ver: %d.%02d\nAvailable: %@\n\nDo you want to update firmware?\n\nDO NOT DISCONNECT LINEA DURING FIRMWARE UPDATE!",nil),[linea emsrGetFirmwareVersion]/100,[linea emsrGetFirmwareVersion]%100,[info objectForKey:@"firmwareRevision"]]
                                                           delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel",nil) otherButtonTitles:NSLocalizedString(@"Update",nil), nil];
            [alert show];
		}else {
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Firmware Update",nil)
															message:NSLocalizedString(@"No firmware for this device model present",nil) delegate:nil cancelButtonTitle:NSLocalizedString(@"Ok",nil) otherButtonTitles:nil, nil];
			[alert show];
		}
	}
}

-(void)bluetoothDeviceDiscovered:(NSString *)btAddress name:(NSString *)btName
{
    [printers addObject:btAddress];
    [printers addObject:btName];
}

-(void)bluetoothDiscoverComplete:(BOOL)success
{
    [progressViewController.view removeFromSuperview];
    [linea btmSetEnabled:FALSE];
    [settingsTable reloadData];
    if(!success)
        [self displayAlert:NSLocalizedString(@"Bluetooth Error",nil) message:NSLocalizedString(@"Printer discovery failed!",nil)];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Number of sections is the number of region dictionaries
    return 5;
}

- (NSString *)tableView:(UITableView *)aTableView titleForHeaderInSection:(NSInteger)section {
	switch (section)
	{
		case 0:
			return NSLocalizedString(@"General Settings",nil);
		case 1:
			return NSLocalizedString(@"Barcode Settings",nil);
		case 2:
			return @"";
		case 3:
			return NSLocalizedString(@"Bluetooth printers",nil);
		case 4:
			return NSLocalizedString(@"Firmware Update",nil);
	}
	return @"";
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Number of rows is the number of names in the region dictionary for the specified section
	switch (section)
	{
		case 0:
			return 9;
		case 1:
			return BAR_LAST-1;
		case 2:
			return 2;
		case 3:
			return [printers count]/2+1;
		case 4:
			return 2;
	}
	return 0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(linea.connstate!=CONN_CONNECTED)
		return;
	
	switch ([indexPath indexAtPosition:0])
	{
		case 0:
        {
			NS_DURING
			if(settings_values[indexPath.row])
			{
				settings_values[indexPath.row]=FALSE;
			}else
			{
				settings_values[indexPath.row]=TRUE;
			}
			switch (indexPath.row)
            {
                case SET_BEEP:
                case SET_ALTERNATIVE_BEEP:
                    if(settings_values[1])
                    {
                        [linea setScanBeep:settings_values[0] volume:100 beepData:beep2 length:sizeof(beep2)]; 
                    }else
                    {
                        [linea setScanBeep:settings_values[0] volume:100 beepData:beep1 length:sizeof(beep1)]; 
                    }
                    break;
                case SET_ENABLE_SCAN_BUTTON:
                    [linea setScanButtonMode:settings_values[2]];
                    break;
                case SET_MULTI_SCAN_MODE:
                    [linea setScanMode:settings_values[3]];
                    break;
                case SET_SCAN_TIMEOUT: //sets timeout to 6 seconds if enabled
                    [linea setScanTimeout:settings_values[4]?6:0];
                    break;
                case SET_MSR_RAW:
                    [linea setMSCardDataMode:settings_values[5]];
                    break;
                case SET_SYNC_BUTTON:
                    [linea setSyncButtonMode:settings_values[6]];
                    break;
                case SET_AUTOCHARGING:
                {
                    [[NSUserDefaults standardUserDefaults] setBool:settings_values[7] forKey:@"AutoCharging"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    NS_DURING
                    [linea setCharging:settings_values[7]];
                    NS_HANDLER
                    NS_ENDHANDLER;
                    break;
                }
                case SET_ENGINE_ON:
                    [[NSUserDefaults standardUserDefaults] setBool:settings_values[8] forKey:@"BarcodeEngineOn"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    [linea barcodeEnginePowerControl:settings_values[8]];
                    break;
            }
			[[tableView cellForRowAtIndexPath: indexPath] setAccessoryType:settings_values[indexPath.row]?UITableViewCellAccessoryCheckmark:UITableViewCellAccessoryNone];
			NS_HANDLER
			NS_ENDHANDLER
			break;
        }
		case 1:
        {
			NS_DURING
			if([linea isBarcodeSupported:(indexPath.row+1)])
			{
				if([linea isBarcodeEnabled:(indexPath.row+1)])
				{
					[linea enableBarcode:(indexPath.row+1) enabled:FALSE];
				}else
				{
					[linea enableBarcode:(indexPath.row+1) enabled:TRUE];
				}
				[settingsTable reloadData];
			}
			NS_HANDLER
			[scannerViewController debug:[NSString stringWithFormat:@"***%@ - %@",[localException name],[localException reason]]];
			NS_ENDHANDLER
			break;
        }
		case 2:
        {
			NS_DURING
			switch (indexPath.row)
            {
                case 0:
                    [linea enableBarcode:BAR_ALL enabled:TRUE];
                    break;
                case 1:
                    [linea enableBarcode:BAR_ALL enabled:FALSE];
                    break;
            }
			NS_HANDLER
			[scannerViewController debug:[NSString stringWithFormat:@"***%@ - %@",[localException name],[localException reason]]];
			NS_ENDHANDLER
			[tableView reloadData];
			break;
        }
		case 3:
        {
			if(indexPath.row)
			{
				selectedPrinterAddress=[printers objectAtIndex:(indexPath.row-1)*2];
                selectedPrinterName=[printers objectAtIndex:(indexPath.row-1)*2+1];
                NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
                [prefs setObject:selectedPrinterAddress forKey:@"selectedPrinterAddress"];
                [prefs setObject:selectedPrinterName forKey:@"selectedPrinterName"];
                [prefs synchronize];
                [tableView reloadData];
			}else {
				//scan for printers
                [progressViewController viewWillAppear:FALSE];
				[self.view addSubview:progressViewController.view];
				[[NSRunLoop currentRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.01]];
				NS_DURING
				[linea btmSetEnabled:TRUE];
                [printers removeAllObjects];
                [linea prnDiscoverPrintersInBackground:10 maxTime:10.0];
				NS_HANDLER
				[linea btmSetEnabled:FALSE];
				[progressViewController.view removeFromSuperview];
				[self displayAlert:NSLocalizedString(@"Bluetooth Error",nil) message:[NSString stringWithFormat:NSLocalizedString(@"Printer discovery failed with error:\n%@\nReason:\n%@",nil),[localException name],[localException reason]]];
				NS_ENDHANDLER
			}
			break;
        }
		case 4:
        {
			NS_DURING
            fwUpdateTarget=indexPath.row;
            if(fwUpdateTarget==TARGET_LINEA)
                [self checkForLineaFirmwareUpdate];
            else
                [self checkForEMSRFirmwareUpdate];
			NS_HANDLER
			[self displayAlert:NSLocalizedString(@"Firmware Update",nil) message:NSLocalizedString(@"Firmware update failed! Please disconnect and reconnect your device.",nil)];
			NS_ENDHANDLER
			break;
        }
	}
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	CGRect CellFrame = CGRectMake(0, 0, 300, 60);
	UITableViewCell *cell;
	
	switch ([indexPath indexAtPosition:0])
	{
		case 0:
        {
			cell = [[UITableViewCell alloc] initWithFrame:CellFrame];
			if(settings_values[indexPath.row])
				cell.accessoryType=UITableViewCellAccessoryCheckmark;
			else
				cell.accessoryType=UITableViewCellAccessoryNone;
			[[cell textLabel] setText:NSLocalizedString(settings[indexPath.row],nil)];
			return cell;
        }
		case 1:
        {
			NS_DURING
			cell = [[UITableViewCell alloc] initWithFrame:CellFrame];
			if([linea isBarcodeSupported:(indexPath.row+1)])
			{
				if([linea isBarcodeEnabled:(indexPath.row+1)])
					cell.accessoryType=UITableViewCellAccessoryCheckmark;
				else
					cell.accessoryType=UITableViewCellAccessoryNone;
				[cell textLabel].textColor=[UIColor colorWithRed:0 green:0 blue:0 alpha:1];
			}else
			{
				[cell textLabel].textColor=[UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:0.5];
			}
			NS_HANDLER
			[scannerViewController debug:[NSString stringWithFormat:@"***%@ - %@",[localException name],[localException reason]]];
			NS_ENDHANDLER
			[[cell textLabel] setText:[linea barcodeType2Text:indexPath.row+1]];
			return cell;
        }
		case 2:
        {
			cell = [[UITableViewCell alloc] initWithFrame:CellFrame];
			switch (indexPath.row)
            {
                case 0:
                    [[cell textLabel] setText:NSLocalizedString(@"Enable all barcodes",nil)];
                    break;
                case 1:
                    [[cell textLabel] setText:NSLocalizedString(@"Disable all barcodes",nil)];
                    break;
            }
			return cell;
        }
		case 3:
        {
			cell = [[UITableViewCell alloc] initWithFrame:CellFrame];
			if(indexPath.row)
			{
				[[cell textLabel] setText:[NSString stringWithFormat:@"%@ (%@)",[printers objectAtIndex:(indexPath.row-1)*2+1],[printers objectAtIndex:(indexPath.row-1)*2]]];
				if(selectedPrinterAddress && [[printers objectAtIndex:(indexPath.row-1)*2] isEqualToString:selectedPrinterAddress])
					cell.accessoryType=UITableViewCellAccessoryCheckmark;
				else
					cell.accessoryType=UITableViewCellAccessoryNone;
			}else
				[[cell textLabel] setText:NSLocalizedString(@"Discover printers",nil)];
			return cell;
        }
		case 4:
        {
			cell = [[UITableViewCell alloc] initWithFrame:CellFrame];
			switch (indexPath.row)
            {
                case 0:
                    [[cell textLabel] setText:NSLocalizedString(@"Update Linea firmware",nil)];
                    break;
                case 1:
                    [[cell textLabel] setText:NSLocalizedString(@"Update Encrypted Head firmware",nil)];
                    break;
            }
        }
			return cell;
	}
	return nil;	
}

- (void)viewWillAppear:(BOOL)animated
{
	NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
	selectedPrinterAddress=[prefs objectForKey:@"selectedPrinterAddress"];
	selectedPrinterName=[prefs objectForKey:@"selectedPrinterName"];
    if(![printers count] && selectedPrinterAddress)
    {
        [printers addObject:selectedPrinterAddress];
        [printers addObject:selectedPrinterName];
        [settingsTable reloadData];
    }
	
	//update display according to current linea state
	[self connectionState:linea.connstate];
}


- (void)viewDidLoad
{
	linea=[Linea sharedDevice];
	[linea addDelegate:self];
    printers=[[NSMutableArray alloc] init];
    [super viewDidLoad];
}

@end
