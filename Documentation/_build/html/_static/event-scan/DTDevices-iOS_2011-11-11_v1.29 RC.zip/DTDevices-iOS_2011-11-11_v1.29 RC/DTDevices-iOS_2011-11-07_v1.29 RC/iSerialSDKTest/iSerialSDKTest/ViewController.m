#import "ViewController.h"

@implementation ViewController

@synthesize btDeviceAddress;

-(void)debug:(NSString *)string
{
	[logStr appendString:string];
	[logStr appendString:@"\r\n"];
    [log performSelectorOnMainThread:@selector(setText:) withObject:logStr waitUntilDone:NO];
}

-(void)debugdata:(NSString *)label data:(uint8_t *)data length:(int)length;
{
	const char HEX[]="0123456789ABCDEF";
	char s[2000];
	for(int i=0;i<length && i<20;i++)
	{
		s[i*3]=HEX[data[i]>>4];
		s[i*3+1]=HEX[data[i]&0x0f];
		s[i*3+2]=' ';
	}
	s[length*3]=0;
	if(length>20)
		strcat(s,"...");
	[self debug:[NSString stringWithFormat:@"%@(%.2d): %s",label,length,s]];
}

-(void)iSerialConnected
{
    [self debug:[NSString stringWithFormat:@"%@ %@ HW: %@, FW: %@\nSn: %@\nSerial: %@\nBluetooth: %@",iserial.deviceName,iserial.deviceModel,iserial.hardwareRevision,iserial.firmwareRevision,iserial.serialNumber,iserial.serialSupported?@"yes":@"no",iserial.bluetoothSupported?@"yes":@"no"]];
    iserial.inputStream.delegate=self;
    [iserial.inputStream open];
    iserial.outputStream.delegate=self;
    [iserial.outputStream open];
    if(iserial.serialSupported)
    {
        [iserial serialSetSettingsBaud:115200 parity:PARITY_NONE dataBits:DATABITS_8 stopBits:STOPBITS_1 flowControl:FLOW_NONE error:nil];
        [iserial serialConnect:nil];
    }
}

-(void)iSerialDisconnected
{
    [self debug:@"Disconnected!"];
}

//STREAM:HANDLEEVENT IS SENT FROM A THREAD!!!
-(void)stream:(NSStream *)stream handleEvent:(NSStreamEvent)eventCode
{
    switch(eventCode)
    {
        case NSStreamEventOpenCompleted:
        {
            [self debug:@"stream:handleEvent: eventCode NSStreamEventOpenCompleted"];
            break;
        }
        case NSStreamEventHasBytesAvailable:
        {   
            uint8_t buf[8192];
            int length=[iserial.inputStream read:buf maxLength:sizeof(buf)];
            [self debugdata:@"R" data:buf length:length];
            break;
        }
            
        case NSStreamEventEndEncountered:
            [self debug:@"stream:handleEvent: eventCode NSStreamEventEndEncountered"];
            break;
    }
}

/**
 Notification sent when bluetooth discovery completes successfully, even if no devices are found
 **/
-(void)bluetoothDiscoveryComplete
{
    [self debug:@"BT Discovery complete"];
}

/**
 Notification sent when bluetooth discovery fails.
 @param error the error code and description
 **/
-(void)bluetoothDiscoveryFailedWithError:(NSError *)error
{
    [self debug:[NSString stringWithFormat:@"BT Discover completed with error: %@",[error localizedDescription]]];
}

/**
 Notification sent when bluetooth discovery finds new bluetooth device
 @param btAddress bluetooth address of the device
 @param btName bluetooth name of the device
 **/
-(void)bluetoothDeviceDiscovered:(NSString *)btAddress name:(NSString *)btName
{
    self.btDeviceAddress=btAddress;
    [self debug:[NSString stringWithFormat:@"Discovered: %@ (%@)",btName,btAddress]];
}

- (IBAction)onBTDiscover:(id)sender
{
    NSError *err;
    [iserial btSetEnabled:FALSE error:nil];
    if(![iserial btSetEnabled:TRUE error:&err])
    {
        [self debug:[NSString stringWithFormat:@"BT Module enabling failed with error: %@",[err localizedDescription]]];
        return;
    }
    
    if(![iserial btDiscoverDevicesInBackground:10 maxTime:10 codTypes:0 error:&err])
    {
        [self debug:[NSString stringWithFormat:@"BT Discover failed with error: %@",[err localizedDescription]]];
        return;
    }
    [self debug:@"Bluetooth discover pending..."];
}

- (IBAction)onBTConnect:(id)sender
{
    if(btDeviceAddress!=nil)
    {
        NSError *err;
        
        if(![iserial btConnect:btDeviceAddress pin:@"0000" error:&err])
        {
            [self debug:[NSString stringWithFormat:@"BT Connect failed with error: %@",[err localizedDescription]]];
        }
    }else
    {
        [self debug:@"Please discover devices first"];
    }
}

- (IBAction)onBTDisconnect:(id)sender
{
    self.btDeviceAddress=nil;
    [iserial btSetEnabled:FALSE error:nil];
}


-(BOOL)textFieldShouldEndEditing:(UITextField *)theTextField;
{
	return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField;
{
	[textField resignFirstResponder];
	return YES;
}

- (IBAction)onTextSend:(id)sender
{
	if(iserial.connected)
	{
		char buf[500];
		int len=[text.text length];
		
		[text.text getCString:buf maxLength:500 encoding:NSASCIIStringEncoding];
		
		[iserial.outputStream write:(uint8_t *)buf maxLength:len];
		
		[self debugdata:@"W" data:(uint8_t *)buf length:len];
	}
}

uint8_t hexbuf[500];
int hexlen=0;

- (IBAction)onHexSend:(id)sender
{
	if(iserial.connected)
	{
		char buf[500];
		int len=[hex.text length];
		
		hexlen=0;
		
		[hex.text getCString:buf maxLength:500 encoding:NSASCIIStringEncoding];
		for(int i=0;i<len-1;i++)
		{
			if( ((buf[i]>='0' && buf[i]<='9') || (buf[i]>='A' && buf[i]<='F')) && ((buf[i+1]>='0' && buf[i+1]<='9') || (buf[i+1]>='A' && buf[i+1]<='F')) )
			{
				if(buf[i]>='0' && buf[i]<='9')
					hexbuf[hexlen]=(buf[i]-'0')<<4;
				else
					hexbuf[hexlen]=(buf[i]-'A'+0xA)<<4;
				i++;
				if(buf[i]>='0' && buf[i]<='9')
					hexbuf[hexlen]|=(buf[i]-'0');
				else
					hexbuf[hexlen]|=(buf[i]-'A'+0xA);
				hexlen++;
			}
		}
		if(hexlen>0)
		{
            [iserial.outputStream write:(uint8_t *)hexbuf maxLength:hexlen];
		}
	}
}

- (IBAction)onClear:(id)sender
{
	[logStr setString:@""];
	[log setText:@""];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    logStr=[[NSMutableString alloc] init];
    iserial=[[iSerial alloc] init];
    iserial.delegate=self;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
