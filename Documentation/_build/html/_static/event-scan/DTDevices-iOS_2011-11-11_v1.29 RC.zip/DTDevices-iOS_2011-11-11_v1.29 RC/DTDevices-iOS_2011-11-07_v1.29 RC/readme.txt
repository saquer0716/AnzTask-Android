Warning: the new universal library was created from the old libLineaSDK.a and as such, it is function compatible with it.
The only functions that were dropped from the original LineaSDK were the never officially released printer functions.
In order to update existing project to use the new universal library (libdtdev.a), the only thing that should be done
is to remove the reference to libLineaSDK.a and add it instead.

Warning: XCode 4.2 release supports Automatic Reference Counting (ARC) feature, that greatly reduces the risk of memory
issues and streamlines the development. With ARC, however, the exception handling was changed to be unsafe by default -
that means, object allocated within @try @catch statements will leak upon raising exception. The bad news - the SDK relies
on exceptions and this means huge potential leaks when program is compiled with ARC. Thankfully, new compiler option
solves that, so if you want to use the library with ARC, then go to target settings and put -fobjc-arc-exceptions
in Other C flags line.
The other thing ARC did was to disallow object inside structures, and there are a couple of functions in Linea and Printer
SDKs that use that, they were replaced by NSDictionary versions, so if you are going to update to ARC, you have to switch
over to these new functions. Demo programs were updated to reflect that