#import "MifareViewController.h"


@implementation MifareViewController

-(BOOL)textFieldShouldEndEditing:(UITextField *)theTextField;
{
	return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField;
{
	[textField resignFirstResponder];
	return YES;
}

-(void)displayAlert:(NSString *)title message:(NSString *)message
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:message delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
	[alert show];
}

#define MF_COMMAND(operation,c) {int stat=c; if(stat!=MF_STAT_OK)[NSException raise:@"MifareFailedException" format:@"%@ failed, error code: %d",operation,stat]; }

-(IBAction)selectCard:(id)sender
{
	NS_DURING
	[self displayAlert:@"Operation successful!" message:@"\n"];
	NS_HANDLER
	[self displayAlert:@"Operation failed!" message:[NSString stringWithFormat:@"%@ - %@",[localException name],[localException reason]]];
	NS_ENDHANDLER
}

static BOOL stringToHex(NSString *str, uint8_t *data, int length)
{
    NSString *t=[[str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] lowercaseString];
    if([t length]!=(length*3-1))
        return FALSE;
    for(int i=0;i<[t length];i++)
    {
        char c=[t characterAtIndex:i];
        if((c<'0' || c>'9') && (c<'a' || c>'f') && c!=' ')
            return FALSE;
    }
        
    for(int i=0;i<length;i++)
    {
        char c=[t characterAtIndex:i*3];
        if(c>='a')
            data[i]=c-'a'+10;
        else
            data[i]=c-'0';
        data[i]<<=4;
        
        c=[t characterAtIndex:i*3+1];
        if(c>='a')
            data[i]|=c-'a'+10;
        else
            data[i]|=c-'0';
    }
    return true;
}

static NSString *hexToString(NSString * label, void *data, int length)
{
	const char HEX[]="0123456789ABCDEF";
	char s[2000];
	for(int i=0;i<length;i++)
	{
		s[i*3]=HEX[((uint8_t *)data)[i]>>4];
		s[i*3+1]=HEX[((uint8_t *)data)[i]&0x0f];
		s[i*3+2]=' ';
	}
	s[length*3]=0;
	
    if(label)
        return [NSString stringWithFormat:@"%@(%d): %s",label,length,s];
    else
        return [NSString stringWithCString:s encoding:NSASCIIStringEncoding];
}

-(void)prepareCard
{
    //init
    MF_COMMAND(NSLocalizedString(@"Init",nil),[linea mfInit]);
 
    //request cards
    MF_COMMAND(NSLocalizedString(@"Request cards",nil),[linea mfRequestCards:TRUE rq1:nil rq2:nil]);

    //if card was found - get the serial
    uint32_t serial;
    MF_COMMAND(NSLocalizedString(@"Anticollision",nil),[linea mfAnticollision:&serial]);
    [serialLabel setText:[NSString stringWithFormat:@"%4X",serial]];

    //select the card to work with
    uint8_t sack;
    MF_COMMAND(NSLocalizedString(@"Select card",nil),[linea mfSelectCard:serial sack:&sack]);

    //authenticate with the block to read or write
    uint8_t key[6];
    if(!stringToHex(keyField.text,key,sizeof(key)))
    {
        [self displayAlert:NSLocalizedString(@"Operation failed!",nil) message:NSLocalizedString(@"Key has invalid characters or length",nil)];
        return;
    }
    MF_COMMAND(NSLocalizedString(@"Authentication",nil),[linea mfAuthByKey:keyTypeControl.selectedSegmentIndex==0?'A':'B' block:[blockField.text intValue] key:key]);
}

-(IBAction)readCard:(id)sender
{
	NS_DURING
    [self prepareCard];
    
    //read block
    uint8_t data[16];
    MF_COMMAND(NSLocalizedString(@"Read block",nil),[linea mfRead:[blockField.text intValue] data:data]);
    [dataField setText:hexToString(nil,data,sizeof(data))];
	[self displayAlert:NSLocalizedString(@"Operation successful!",nil) message:@"\n"];
	NS_HANDLER
	[self displayAlert:NSLocalizedString(@"Operation failed!",nil) message:[NSString stringWithFormat:@"%@ - %@",[localException name],[localException reason]]];
	NS_ENDHANDLER
    [linea mfClose];
}

-(IBAction)writeCard:(id)sender
{
	NS_DURING
    uint8_t data[16];
    if(!stringToHex(dataField.text,data,sizeof(data)))
    {
        [self displayAlert:NSLocalizedString(@"Operation failed!",nil) message:NSLocalizedString(@"Data has invalid characters or length",nil)];
        return;
    }

    [self prepareCard];
    
    //write block
    MF_COMMAND(NSLocalizedString(@"Write block",nil),[linea mfWrite:[blockField.text intValue] data:data]);
	[self displayAlert:NSLocalizedString(@"Operation successful!",nil) message:@"\n"];
	NS_HANDLER
	[self displayAlert:NSLocalizedString(@"Operation failed!",nil) message:[NSString stringWithFormat:@"%@ - %@",[localException name],[localException reason]]];
	NS_ENDHANDLER
}

-(void)viewWillAppear:(BOOL)animated
{
}

-(void)viewWillDisappear:(BOOL)animated
{
}

-(void)viewDidLoad
{
	keyField.delegate=self;
	blockField.delegate=self;
	dataField.delegate=self;
	
	//we don't care about Linea notifications here, so won't add the delegate
	linea=[Linea sharedDevice];
    [super viewDidLoad];
}


@end
