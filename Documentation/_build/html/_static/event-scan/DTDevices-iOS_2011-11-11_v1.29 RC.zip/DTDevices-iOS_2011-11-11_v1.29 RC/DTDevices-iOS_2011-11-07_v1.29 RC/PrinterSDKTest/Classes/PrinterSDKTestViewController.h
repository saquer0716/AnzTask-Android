#import <UIKit/UIKit.h>
#import "PrinterSDK.h"

@interface PrinterSDKTestViewController : UIViewController {
	Printer *prn;
	NSMutableString *debug;
	
	IBOutlet UIImageView *statusImage;
	IBOutlet UIImageView *battery;
	IBOutlet UITextView *debugText;
	IBOutlet UITextView *displayText;
    IBOutlet UILabel *paperStatusLabel;
    
    IBOutlet UIButton *btDiscover;
    IBOutlet UIButton *btConnect;
    IBOutlet UIButton *btDisconnect;
}

- (IBAction)selfTest:(id)sender;
- (IBAction)fontsDemo:(id)sender;
- (IBAction)graphicsDemo:(id)sender;
- (IBAction)readMagneticCard:(id)sender;
- (IBAction)scanBarcode:(id)sender;
- (IBAction)barcodesDemo:(id)sender;
- (IBAction)onClearLog:(id)sender;
- (IBAction)onSetEncryptionKey:(id)sender;

- (IBAction)onBTDiscover:(id)sender;
- (IBAction)onBTConnect:(id)sender;
- (IBAction)onBTDisconnect:(id)sender;

@property(copy) NSString *btDeviceAddress;

@end

