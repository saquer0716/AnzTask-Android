#import "MainTabBarController.h"
#import "NSDataCrypto.h"

@implementation MainTabBarController

-(void)enableCharging {
	NS_DURING
    [linea setCharging:[[NSUserDefaults standardUserDefaults] boolForKey:@"AutoCharging"]];
    NS_HANDLER
    NS_ENDHANDLER
}

-(void)connectionState:(int)state {
	switch (state) {
		case CONN_DISCONNECTED:
		case CONN_CONNECTING:
#if TARGET_IPHONE_SIMULATOR
			[self setViewControllers:[NSArray arrayWithObjects:scannerViewController,settingsViewController,cryptoViewController,mifareViewController,iso15693ViewController,nil] animated:TRUE];
#else
			[self setViewControllers:[NSArray arrayWithObject:scannerViewController] animated:FALSE];
#endif
			break;
		case CONN_CONNECTED:
			NS_DURING
			[linea msStartScan];
            //keep the egine on by default, this is useful for 2D barcode engine that takes several seconds to power on
            if(![[NSUserDefaults standardUserDefaults] objectForKey:@"BarcodeEngineOn"])
            {
                [[NSUserDefaults standardUserDefaults] setBool:TRUE forKey:@"BarcodeEngineOn"];
                [[NSUserDefaults standardUserDefaults] synchronize];
            }
            [linea barcodeEnginePowerControl:[[NSUserDefaults standardUserDefaults] boolForKey:@"BarcodeEngineOn"]];
            [linea setCharging:[[NSUserDefaults standardUserDefaults] boolForKey:@"AutoCharging"]];
            [linea setBarcodeTypeMode:BARCODE_TYPE_DEFAULT];
			
			//calling this function last, after all notifications has been called in all registered deleegates, 
			//because enabling/disabling charge in firmware versions <2.34 will force disconnect and reconnect
			[self performSelectorOnMainThread:@selector(enableCharging) withObject:nil waitUntilDone:NO];
			NS_HANDLER
			[scannerViewController debug:[NSString stringWithFormat:@"***%@ - %@",[localException name],[localException reason]]];
			NS_ENDHANDLER
			
			[self setViewControllers:[NSArray arrayWithObjects:scannerViewController,settingsViewController,cryptoViewController,mifareViewController,iso15693ViewController,nil] animated:FALSE];
			break;
	}
}

-(void)viewWillAppear:(BOOL)animated
{
}

-(void)viewWillDisappear:(BOOL)animated
{
}

-(void)viewDidLoad
{
	//init linea class and connect it
	linea=[Linea sharedDevice];
	[linea addDelegate:self];
	[linea connect];
    [super viewDidLoad];
}

-(void)dealloc
{
	[linea disconnect];
}

@end
