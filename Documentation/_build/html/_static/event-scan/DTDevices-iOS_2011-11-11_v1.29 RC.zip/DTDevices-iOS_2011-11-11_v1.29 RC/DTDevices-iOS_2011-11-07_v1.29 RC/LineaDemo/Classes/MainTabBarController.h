#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "ScannerViewController.h"
#import "SettingsViewController.h"
#import "CryptoViewController.h"
#import "MifareViewController.h"
#import "ISO15693ViewController.h"

@interface MainTabBarController : UITabBarController <LineaDelegate> {
	IBOutlet ScannerViewController *scannerViewController;
	IBOutlet SettingsViewController *settingsViewController;
	IBOutlet CryptoViewController *cryptoViewController;
	IBOutlet MifareViewController *mifareViewController;
	IBOutlet ISO15693ViewController *iso15693ViewController;
	
	Linea *linea;
}

@end
