#import <Foundation/Foundation.h>
#import "LineaSDK.h"


@interface ISO15693ViewController : UIViewController <UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate> {
    IBOutlet UITableView *cardsTableView;
    
	IBOutlet UITextField *readBlockField;
	IBOutlet UITextField *readBlockNumField;
	IBOutlet UITextView *readDataView;
	IBOutlet UITextField *writeBlockField;
	IBOutlet UITextField *writeDataField;
    
	Linea *linea;
    int selectedCard;
}

-(IBAction)readCard:(id)sender;
-(IBAction)writeCard:(id)sender;
-(IBAction)scanCards:(id)sender;

@property(strong) NSArray *cards;

@end
