//
//  ViewController.h
//  iSerialSDKTest
//
//  Created by Anton Rajnov on 10/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "iSerialSDK.h"

@interface ViewController : UIViewController <NSStreamDelegate>
{
	IBOutlet UITextView *log;
	IBOutlet UITextField *text;
	IBOutlet UITextField *hex;
	IBOutlet UIButton *sendText;
	IBOutlet UIButton *sentHex;
	IBOutlet UIButton *clear;
    
    UIWindow *window;
	
    NSMutableString *logStr;
    iSerial *iserial;
}

- (IBAction)onTextSend:(id)sender;
- (IBAction)onHexSend:(id)sender;
- (IBAction)onClear:(id)sender;

- (IBAction)onBTDiscover:(id)sender;
- (IBAction)onBTConnect:(id)sender;
- (IBAction)onBTDisconnect:(id)sender;

@property(copy) NSString *btDeviceAddress;
@end
