#import <Foundation/Foundation.h>
#import "LineaSDK.h"


@interface MifareViewController : UIViewController <UITextFieldDelegate> {
	IBOutlet UITextField *keyField;
	IBOutlet UITextField *blockField;
	IBOutlet UITextField *dataField;
    IBOutlet UILabel *serialLabel;
    IBOutlet UISegmentedControl *keyTypeControl;
    
	Linea *linea;
}

-(IBAction)readCard:(id)sender;
-(IBAction)writeCard:(id)sender;

@end
